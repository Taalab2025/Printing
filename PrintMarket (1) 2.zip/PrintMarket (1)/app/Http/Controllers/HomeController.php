<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    // This method will return the view for the homepage.
    public function index()
    {
        return view('welcome'); // Adjust this view name as needed
    }
}
