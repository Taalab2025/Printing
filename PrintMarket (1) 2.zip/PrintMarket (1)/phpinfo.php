<?php
// phpinfo.php
phpinfo();