<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Print Market</title>
</head>
<body>
    <h1>Welcome to the Print Market!</h1>
    <p>This is the custom homepage for the application you created.</p>
</body>
</html>
